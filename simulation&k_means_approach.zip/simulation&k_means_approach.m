% written by Pan Lishuo 2017/9/22
%aim: test the power of the K-means approach
%dataset1, sample size 100, p = 8


clc; clear;
size = 10000; p =100; group = 100; rng(2);mu_range = 100;var_range = 4;

%%
% 10-folds
group_index = randi([1,group],1,size);
for i = 1 : group;
    eval(['group',char(num2str(i)),'_index', ...
        '= find(group_index ==', char(num2str(i)),');']);
end

rng(3);
%generate a distribution for each regrossor i in each group j Pr(i,j)
for i = 1 : group;
    eval(['group',char(num2str(i)),'_mu_list', ...
        '= randi([1,mu_range],1,p);']);
    eval(['group',char(num2str(i)),'_var_list', ...
        '= randi([1,var_range],1,p);']);
end
for i = 1:p;
    for j = 1:group;
        eval(['distribution_group',char(num2str(j)),'_p',char(num2str(i)), ...
            '= normrnd(group',char(num2str(j)),'_mu_list(i),', ...
            'group',char(num2str(j)),'_var_list(i),', ...
            '1,','length(','group',char(num2str(j)),'_index));']);
    end
end
%generate each group's data
for i = 1:group;
    eval(['distribution_group',char(num2str(i)),'=[];']);
    for j = 1:p;
        eval(['distribution_group',char(num2str(i)), ...
            '= [distribution_group',char(num2str(i)),';', ...
            'distribution_group',char(num2str(i)),'_p',char(num2str(j)),']; ']);
    end
    eval(['distribution_group',char(num2str(i)), ...
        '=distribution_group',char(num2str(i)),'''',';']);
    eval(['distribution_group',char(num2str(i)), ...
        '=[distribution_group',char(num2str(i)), ...
        ', repmat(i,length(group',char(num2str(i)),'_index),1)];']);
end
%generate the whole data with labled group index
simulate_data = [];
for i = 1 : group;
    eval(['simulate_data =', ...
        '[simulate_data; distribution_group',char(num2str(i)),'];'
        ]);
    
end


%%
%core code of K-means
[idx c] = kmeans(simulate_data(:,1:p), group);
simulate_data = [simulate_data, idx];

%%
%calculate the error rate for k-means approach
result_kmeans = zeros(1,group)';
for i = 1:group;
    frequence = mode(simulate_data(find(simulate_data(:,p+1)==i),p+2));
    iresult_kmeans = ...
        length(find(simulate_data(find(simulate_data(:,p+1)==i),p+2)==frequence));
    result_kmeans(i) = iresult_kmeans;
end
(size - sum(result_kmeans)) / size